package com.ieseljust;

public class App {
    public static void main(String[] args) {
        System.out.println("Hola, món des de Gradle!");
    }
}
